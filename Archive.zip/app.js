// Configuration for Workers endpoint
const WORKER_URL = "https://audio-stream-proxy.ikisuketestapp.workers.dev"; // Replace with your Workers URL

// Web Audio API Streaming Implementation
class WebAudioStreamer {
  constructor() {
    this.audioContext = null;
    this.isPlaying = false;
    this.nextStartTime = 0;
    this.accumulatedData = [];
    this.totalBytes = 0;
    this.minBufferSize = 32768; // 32KB minimum before attempting decode
    this.maxBufferSize = 131072; // 128KB max before forcing decode attempt
    this.decodedBuffers = [];
    this.isDecoding = false;
  }

  async start() {
    try {
      this.audioContext = new (window.AudioContext ||
        window.webkitAudioContext)();
      
      updateStatus("webAudio", "ストリーミング開始...", "loading");
      
      // Use the new streaming endpoint
      const response = await fetch(`${WORKER_URL}/stream/audio/2`);
      const reader = response.body.getReader();
      
      this.isPlaying = true;
      this.nextStartTime = this.audioContext.currentTime + 0.1; // Small initial buffer
      
      // Start reading and playing chunks
      this.processStream(reader);
      
      updateStatus("webAudio", "ストリーミング中", "playing");
    } catch (error) {
      updateStatus("webAudio", "エラー: " + error.message, "error");
      toggleButtons("webAudio", false);
    }
  }
  
  async processStream(reader) {
    let isFirstChunk = true;
    
    while (this.isPlaying) {
      try {
        const { done, value } = await reader.read();
        
        if (done) {
          // Process any remaining data
          if (this.accumulatedData.length > 0) {
            await this.attemptDecode(true);
          }
          
          // Wait for all buffers to finish playing
          while (this.decodedBuffers.length > 0 || this.isDecoding) {
            await new Promise(resolve => setTimeout(resolve, 100));
          }
          
          updateStatus("webAudio", "ストリーミング完了", "");
          toggleButtons("webAudio", false);
          break;
        }
        
        // Accumulate data
        this.accumulatedData.push(value);
        this.totalBytes += value.length;
        
        // Attempt to decode when we have enough data
        if (this.totalBytes >= this.minBufferSize) {
          // For first chunk, wait for more data to ensure smooth start
          if (isFirstChunk && this.totalBytes < this.maxBufferSize) {
            isFirstChunk = false;
            continue;
          }
          
          await this.attemptDecode(false);
        }
      } catch (error) {
        console.error('Stream processing error:', error);
        updateStatus("webAudio", "ストリームエラー: " + error.message, "error");
        toggleButtons("webAudio", false);
        break;
      }
    }
    
    reader.cancel();
  }
  
  async attemptDecode(isFinal) {
    if (this.isDecoding || this.accumulatedData.length === 0) return;
    
    this.isDecoding = true;
    
    try {
      // Combine accumulated chunks
      const fullBuffer = new Uint8Array(this.totalBytes);
      let offset = 0;
      for (const chunk of this.accumulatedData) {
        fullBuffer.set(chunk, offset);
        offset += chunk.length;
      }
      
      // Try to decode
      const audioBuffer = await this.audioContext.decodeAudioData(fullBuffer.buffer.slice(0));
      
      // Success - clear accumulated data
      this.accumulatedData = [];
      this.totalBytes = 0;
      
      // Add to playback queue
      this.decodedBuffers.push(audioBuffer);
      
      // Start playback if not already playing
      if (this.decodedBuffers.length === 1) {
        this.playNextBuffer();
      }
    } catch (decodeError) {
      // If not final and we haven't reached max buffer, keep accumulating
      if (!isFinal && this.totalBytes < this.maxBufferSize) {
        console.log('Waiting for more data to decode...');
      } else {
        console.error('Failed to decode audio chunk:', decodeError);
        // Clear problematic data
        this.accumulatedData = [];
        this.totalBytes = 0;
      }
    } finally {
      this.isDecoding = false;
    }
  }
  
  playNextBuffer() {
    if (!this.isPlaying || this.decodedBuffers.length === 0) return;
    
    const audioBuffer = this.decodedBuffers.shift();
    const source = this.audioContext.createBufferSource();
    source.buffer = audioBuffer;
    source.connect(this.audioContext.destination);
    
    // Ensure continuous playback
    const now = this.audioContext.currentTime;
    if (this.nextStartTime < now) {
      this.nextStartTime = now;
    }
    
    source.start(this.nextStartTime);
    this.nextStartTime += audioBuffer.duration;
    
    source.onended = () => {
      // Play next buffer if available
      if (this.decodedBuffers.length > 0) {
        this.playNextBuffer();
      }
    };
  }

  stop() {
    this.isPlaying = false;
    this.decodedBuffers = [];
    this.accumulatedData = [];
    this.totalBytes = 0;
    if (this.audioContext) {
      this.audioContext.close();
    }
    updateStatus("webAudio", "停止", "");
  }
}

// HLS Implementation
class HLSStreamer {
  constructor() {
    this.hls = null;
    this.audio = document.getElementById("hlsAudio");
  }

  start() {
    if (Hls.isSupported()) {
      this.hls = new Hls();
      // Using a public HLS stream for demo
      this.hls.loadSource(`https://test-streams.mux.dev/x36xhzz/x36xhzz.m3u8`);
      this.hls.attachMedia(this.audio);

      this.hls.on(Hls.Events.MANIFEST_PARSED, () => {
        this.audio.play();
        updateStatus("hls", "再生中", "playing");
      });

      this.hls.on(Hls.Events.ERROR, (event, data) => {
        if (data.fatal) {
          updateStatus("hls", "エラー: " + data.type, "error");
          toggleButtons("hls", false);
        }
      });
    } else if (this.audio.canPlayType("application/vnd.apple.mpegurl")) {
      // For Safari native HLS support
      this.audio.src = `https://test-streams.mux.dev/x36xhzz/x36xhzz.m3u8`;
      this.audio.play();
      updateStatus("hls", "再生中 (Native)", "playing");
    } else {
      updateStatus("hls", "HLSはサポートされていません", "error");
      toggleButtons("hls", false);
    }
  }

  stop() {
    if (this.hls) {
      this.hls.destroy();
      this.hls = null;
    }
    this.audio.pause();
    this.audio.src = "";
    updateStatus("hls", "停止", "");
  }
}

// Media Source Extensions Implementation
class MSEStreamer {
  constructor() {
    this.mediaSource = null;
    this.sourceBuffer = null;
    this.audio = document.getElementById("mseAudio");
    this.queue = [];
    this.isAppending = false;
    this.reader = null;
    this.isStreaming = false;
    this.hasStartedPlayback = false;
    this.totalBytesAppended = 0;
    this.minPlaybackBuffer = 65536; // 64KB before starting playback
  }

  async start() {
    try {
      this.mediaSource = new MediaSource();
      this.audio.src = URL.createObjectURL(this.mediaSource);
      this.isStreaming = true;

      this.mediaSource.addEventListener("sourceopen", async () => {
        try {
          this.sourceBuffer = this.mediaSource.addSourceBuffer("audio/mpeg");
          this.sourceBuffer.mode = "sequence"; // Important for streaming
          
          this.sourceBuffer.addEventListener("updateend", () => {
            this.isAppending = false;
            this.processQueue();
            
            // Start playback once we have enough data
            if (!this.hasStartedPlayback && this.totalBytesAppended >= this.minPlaybackBuffer) {
              this.hasStartedPlayback = true;
              this.audio.play().then(() => {
                updateStatus("mse", "再生中", "playing");
              }).catch(e => {
                console.error("Playback failed:", e);
              });
            }
          });

          this.sourceBuffer.addEventListener("error", (e) => {
            console.error("SourceBuffer error:", e);
          });

          // Start fetching and appending chunks
          await this.fetchAndAppendChunks();
        } catch (error) {
          console.error("SourceBuffer setup error:", error);
          updateStatus("mse", "バッファエラー: " + error.message, "error");
          toggleButtons("mse", false);
        }
      });

      this.mediaSource.addEventListener("sourceended", () => {
        updateStatus("mse", "ストリーミング完了", "");
        toggleButtons("mse", false);
      });

      updateStatus("mse", "バッファリング中...", "loading");
    } catch (error) {
      updateStatus("mse", "エラー: " + error.message, "error");
      toggleButtons("mse", false);
    }
  }

  async fetchAndAppendChunks() {
    try {
      const response = await fetch(`${WORKER_URL}/stream/audio/2`);
      this.reader = response.body.getReader();

      while (this.isStreaming) {
        const { done, value } = await this.reader.read();
        
        if (done) {
          // Wait for any pending appends to complete
          while (this.queue.length > 0 || this.isAppending) {
            await new Promise(resolve => setTimeout(resolve, 50));
          }
          
          if (this.mediaSource.readyState === "open") {
            this.mediaSource.endOfStream();
          }
          break;
        }

        // Add chunk to queue
        this.queue.push(value);
        this.processQueue();
        
        // Prevent queue from growing too large
        if (this.queue.length > 10) {
          await new Promise(resolve => setTimeout(resolve, 100));
        }
      }
    } catch (error) {
      console.error("Streaming error:", error);
      updateStatus("mse", "ストリームエラー: " + error.message, "error");
      toggleButtons("mse", false);
    }
  }

  processQueue() {
    if (this.isAppending || this.queue.length === 0) return;
    if (!this.sourceBuffer || this.sourceBuffer.updating) return;
    
    // Check if we can append more data
    if (this.mediaSource.readyState !== "open") return;

    try {
      this.isAppending = true;
      const chunk = this.queue.shift();
      this.sourceBuffer.appendBuffer(chunk);
      this.totalBytesAppended += chunk.byteLength;
    } catch (error) {
      console.error("Append error:", error);
      this.isAppending = false;
      
      // If quota exceeded, wait a bit and retry
      if (error.name === "QuotaExceededError") {
        setTimeout(() => {
          this.queue.unshift(chunk); // Put chunk back
          this.processQueue();
        }, 1000);
      }
    }
  }

  stop() {
    this.isStreaming = false;
    if (this.reader) {
      this.reader.cancel();
      this.reader = null;
    }
    
    this.audio.pause();
    this.audio.src = "";
    
    if (this.mediaSource && this.mediaSource.readyState === "open") {
      try {
        this.mediaSource.endOfStream();
      } catch (e) {
        console.error("Error ending stream:", e);
      }
    }
    
    this.queue = [];
    this.totalBytesAppended = 0;
    this.hasStartedPlayback = false;
    updateStatus("mse", "停止", "");
  }
}

// Basic HTML5 Audio Streaming
class HTML5Streamer {
  constructor() {
    this.audio = document.getElementById("html5Audio");
  }

  start() {
    this.audio.src = `${WORKER_URL}/audio/3`;
    this.audio.play();
    updateStatus("html5", "再生中", "playing");

    this.audio.addEventListener("ended", () => {
      updateStatus("html5", "再生完了", "");
      toggleButtons("html5", false);
    });

    this.audio.addEventListener("error", (e) => {
      updateStatus("html5", "エラー: " + e.message, "error");
      toggleButtons("html5", false);
    });
  }

  stop() {
    this.audio.pause();
    this.audio.src = "";
    updateStatus("html5", "停止", "");
  }
}

// Chunked Audio Delivery
class ChunkedStreamer {
  constructor() {
    this.audioContext = null;
    this.isPlaying = false;
    this.reader = null;
    this.nextStartTime = 0;
    this.accumulatedData = [];
    this.totalBytes = 0;
    this.targetChunkSize = 65536; // 64KB chunks
    this.decodedChunks = 0;
    this.totalChunks = 0;
    this.playbackQueue = [];
    this.isProcessing = false;
  }

  async start() {
    try {
      this.audioContext = new (window.AudioContext ||
        window.webkitAudioContext)();
      this.isPlaying = true;
      
      updateStatus("chunked", "ストリーミング開始...", "loading");
      document.getElementById("chunkedProgress").value = 0;

      // Use streaming endpoint
      const response = await fetch(`${WORKER_URL}/stream/audio/4`);
      this.reader = response.body.getReader();
      
      this.nextStartTime = this.audioContext.currentTime + 0.1;
      
      // Start streaming and processing
      this.streamChunks();
      
      updateStatus("chunked", "ストリーミング中", "playing");
    } catch (error) {
      updateStatus("chunked", "エラー: " + error.message, "error");
      toggleButtons("chunked", false);
    }
  }

  async streamChunks() {
    while (this.isPlaying) {
      try {
        const { done, value } = await this.reader.read();
        
        if (done) {
          // Process any remaining data
          if (this.accumulatedData.length > 0) {
            await this.processAccumulatedData(true);
          }
          
          // Wait for all audio to finish
          while (this.playbackQueue.length > 0 || this.isProcessing) {
            await new Promise(resolve => setTimeout(resolve, 100));
          }
          
          updateStatus("chunked", "ストリーミング完了", "");
          toggleButtons("chunked", false);
          document.getElementById("chunkedProgress").value = 100;
          break;
        }
        
        // Accumulate data
        this.accumulatedData.push(value);
        this.totalBytes += value.length;
        
        // Process when we have enough data for a chunk
        if (this.totalBytes >= this.targetChunkSize) {
          await this.processAccumulatedData(false);
        }
      } catch (error) {
        console.error('Chunk streaming error:', error);
        updateStatus("chunked", "ストリームエラー: " + error.message, "error");
        toggleButtons("chunked", false);
        break;
      }
    }
    
    if (this.reader) {
      this.reader.cancel();
    }
  }

  async processAccumulatedData(isFinal) {
    if (this.isProcessing || this.accumulatedData.length === 0) return;
    
    this.isProcessing = true;
    
    try {
      // Combine accumulated data
      const combinedBuffer = new Uint8Array(this.totalBytes);
      let offset = 0;
      for (const chunk of this.accumulatedData) {
        combinedBuffer.set(chunk, offset);
        offset += chunk.length;
      }
      
      // Create chunks of target size
      const chunks = [];
      for (let i = 0; i < combinedBuffer.length; i += this.targetChunkSize) {
        const end = Math.min(i + this.targetChunkSize, combinedBuffer.length);
        if (isFinal || (end - i) === this.targetChunkSize) {
          chunks.push(combinedBuffer.slice(i, end));
        } else {
          // Keep partial chunk for next iteration
          this.accumulatedData = [combinedBuffer.slice(i)];
          this.totalBytes = end - i;
          break;
        }
      }
      
      // Clear accumulated data if we processed everything
      if (chunks.length > 0 && (isFinal || this.accumulatedData[0] !== combinedBuffer.slice(chunks.length * this.targetChunkSize))) {
        this.accumulatedData = [];
        this.totalBytes = 0;
      }
      
      // Process each chunk
      for (const chunkData of chunks) {
        this.totalChunks++;
        await this.decodeAndQueueChunk(chunkData);
      }
      
      // Start playback if not already started
      if (this.playbackQueue.length > 0 && this.decodedChunks === 1) {
        this.playNextChunk();
      }
    } finally {
      this.isProcessing = false;
    }
  }

  async decodeAndQueueChunk(chunkData) {
    try {
      // Try to decode the chunk
      const audioBuffer = await this.audioContext.decodeAudioData(chunkData.buffer.slice(0));
      this.playbackQueue.push(audioBuffer);
      this.decodedChunks++;
      
      // Update progress
      const progress = (this.decodedChunks / Math.max(this.totalChunks, 10)) * 100;
      document.getElementById("chunkedProgress").value = Math.min(progress, 95);
    } catch (error) {
      console.log('Skipping chunk that cannot be decoded');
    }
  }

  playNextChunk() {
    if (!this.isPlaying || this.playbackQueue.length === 0) return;
    
    const audioBuffer = this.playbackQueue.shift();
    const source = this.audioContext.createBufferSource();
    source.buffer = audioBuffer;
    source.connect(this.audioContext.destination);
    
    // Ensure continuous playback
    const now = this.audioContext.currentTime;
    if (this.nextStartTime < now) {
      this.nextStartTime = now;
    }
    
    source.start(this.nextStartTime);
    this.nextStartTime += audioBuffer.duration;
    
    source.onended = () => {
      // Update progress based on playback
      const playbackProgress = ((this.decodedChunks - this.playbackQueue.length) / this.decodedChunks) * 100;
      document.getElementById("chunkedProgress").value = Math.min(playbackProgress, 100);
      
      // Play next chunk if available
      if (this.playbackQueue.length > 0) {
        this.playNextChunk();
      }
    };
  }

  stop() {
    this.isPlaying = false;
    if (this.reader) {
      this.reader.cancel();
      this.reader = null;
    }
    if (this.audioContext) {
      this.audioContext.close();
    }
    this.playbackQueue = [];
    this.accumulatedData = [];
    this.totalBytes = 0;
    this.decodedChunks = 0;
    this.totalChunks = 0;
    document.getElementById("chunkedProgress").value = 0;
    updateStatus("chunked", "停止", "");
  }
}

// Utility functions
function updateStatus(method, text, className) {
  const status = document.getElementById(method + "Status");
  status.textContent = text;
  status.className = "status " + className;
}

function toggleButtons(method, isPlaying) {
  document.getElementById(method + "Btn").disabled = isPlaying;
  document.getElementById(method + "StopBtn").disabled = !isPlaying;
}

// Initialize streamers
const streamers = {
  webAudio: new WebAudioStreamer(),
  hls: new HLSStreamer(),
  mse: new MSEStreamer(),
  html5: new HTML5Streamer(),
  chunked: new ChunkedStreamer(),
};

// Event listeners
document.getElementById("webAudioBtn").addEventListener("click", () => {
  toggleButtons("webAudio", true);
  streamers.webAudio.start();
});

document.getElementById("webAudioStopBtn").addEventListener("click", () => {
  toggleButtons("webAudio", false);
  streamers.webAudio.stop();
});

document.getElementById("hlsBtn").addEventListener("click", () => {
  toggleButtons("hls", true);
  streamers.hls.start();
});

document.getElementById("hlsStopBtn").addEventListener("click", () => {
  toggleButtons("hls", false);
  streamers.hls.stop();
});

document.getElementById("mseBtn").addEventListener("click", () => {
  toggleButtons("mse", true);
  streamers.mse.start();
});

document.getElementById("mseStopBtn").addEventListener("click", () => {
  toggleButtons("mse", false);
  streamers.mse.stop();
});

document.getElementById("html5Btn").addEventListener("click", () => {
  toggleButtons("html5", true);
  streamers.html5.start();
});

document.getElementById("html5StopBtn").addEventListener("click", () => {
  toggleButtons("html5", false);
  streamers.html5.stop();
});

document.getElementById("chunkedBtn").addEventListener("click", () => {
  toggleButtons("chunked", true);
  streamers.chunked.isPlaying = true;
  streamers.chunked.start();
});

document.getElementById("chunkedStopBtn").addEventListener("click", () => {
  toggleButtons("chunked", false);
  streamers.chunked.stop();
});
